package se233.chapter3;

import javafx.application.Application;
import javafx.application.HostServices;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Launcher extends Application {
    public static Stage primaryStage;
    public static HostServices hs;
    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        hs = getHostServices();
        FXMLLoader loader = new FXMLLoader(Launcher.class.getResource("main-view.fxml"));
        Scene scene = new Scene(loader.load());
        primaryStage.setTitle("Indexer");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}