package se233.chapter3.controller;

import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Popup;
import se233.chapter3.Launcher;
import se233.chapter3.model.FileFreq;
import se233.chapter3.model.PdfDocument;

import java.io.File;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class MainViewController {
    private Map<String, String> filePathMap = new HashMap<>();
    private LinkedHashMap<String, List<FileFreq>> uniqueSets;

    @FXML
    private ListView<String> inputListView;

    @FXML
    private Button startButton;

    @FXML
    private ListView<String> listView;

    @FXML
    private Region dropRegion;

    @FXML
    private void handleClose() {
        System.exit(0); // This will terminate the application
    }

    @FXML
    public void initialize() {
        // 🎯 Drag & Drop setup
        inputListView.setOnDragOver(event -> {
            Dragboard db = event.getDragboard();
            if (db.hasFiles() && db.getFiles().get(0).getName().toLowerCase().endsWith(".pdf")) {
                event.acceptTransferModes(TransferMode.COPY);
            }
            event.consume();
        });

        inputListView.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            boolean success = false;
            if (db.hasFiles()) {
                for (File file : db.getFiles()) {
                    if (file.getName().toLowerCase().endsWith(".pdf")) {
                        String fileName = file.getName();
                        String fullPath = file.getAbsolutePath();

                        inputListView.getItems().add(fileName); // show only name
                        filePathMap.put(fileName, fullPath);    // store full path
                        success = true;
                    }
                }
            }
            event.setDropCompleted(success);
            event.consume();
        });

        // ▶️ Start button
        startButton.setOnAction(event -> {
            Parent originalRoot = Launcher.primaryStage.getScene().getRoot();

            Task<Void> processTask = new Task<>() {
                @Override
                protected Void call() throws Exception {
                    // 📊 Show loading spinner
                    ProgressIndicator pi = new ProgressIndicator();
                    VBox loadingBox = new VBox(pi);
                    loadingBox.setAlignment(Pos.CENTER);
                    javafx.application.Platform.runLater(() -> Launcher.primaryStage.getScene().setRoot(loadingBox));

                    // 🧵 Setup thread pool
                    ExecutorService executor = Executors.newFixedThreadPool(4);
                    ExecutorCompletionService<Map<String, FileFreq>> ecs = new ExecutorCompletionService<>(executor);

                    List<String> fileNames = inputListView.getItems();
                    int total = fileNames.size();
                    Map<String, FileFreq>[] wordMaps = new Map[total];

                    for (int i = 0; i < total; i++) {
                        String fileName = fileNames.get(i);
                        String fullPath = filePathMap.get(fileName);

                        String log = (fullPath != null) ? fullPath : fileName;
                        System.out.println("📤 Submitting: " + log);

                        final String pathToProcess = fullPath; // effectively final
                        ecs.submit(() -> {
                            try {
                                PdfDocument doc = new PdfDocument(pathToProcess);
                                WordCountMapTask task = new WordCountMapTask(doc);
                                Map<String, FileFreq> result = task.call();
                                System.out.println("✅ Done: " + pathToProcess);
                                return result;
                            } catch (Exception e) {
                                System.out.println("❌ Failed: " + pathToProcess);
                                e.printStackTrace();
                                return Collections.emptyMap();
                            }
                        });
                    }

                    for (int i = 0; i < total; i++) {
                        Future<Map<String, FileFreq>> future = ecs.take();
                        wordMaps[i] = future.get();
                    }

                    // 🔁 Merge
                    WordCountReduceTask merger = new WordCountReduceTask(wordMaps);
                    Future<LinkedHashMap<String, List<FileFreq>>> mergedFuture = executor.submit(merger);
                    uniqueSets = mergedFuture.get();

                    executor.shutdown();

                    // 📤 Push result back to GUI
                    javafx.application.Platform.runLater(() -> {
                        listView.getItems().clear();
                        List<String> formattedList = uniqueSets.entrySet().stream()
                                .sorted((e1, e2) -> {
                                    int sum1 = e1.getValue().stream().mapToInt(FileFreq::getFreq).sum();
                                    int sum2 = e2.getValue().stream().mapToInt(FileFreq::getFreq).sum();
                                    return Integer.compare(sum2, sum1); // descending order
                                })
                                .map(entry -> {
                                    String word = entry.getKey();
                                    List<FileFreq> freqList = entry.getValue();

                                    // Sort frequencies in descending order
                                    List<Integer> freqs = freqList.stream()
                                            .map(FileFreq::getFreq)
                                            .sorted(Comparator.reverseOrder())
                                            .toList();

                                    String freqDisplay = freqs.stream()
                                            .map(Object::toString)
                                            .collect(Collectors.joining(", "));

                                    return word + " (" + freqDisplay + ")";
                                })
                                .toList();

                        listView.getItems().addAll(formattedList);
                        Launcher.primaryStage.getScene().setRoot(originalRoot);
                    });

                    return null;
                }
            };

            processTask.setOnSucceeded(e -> {
                Launcher.primaryStage.getScene().setRoot(originalRoot);
            });
            Thread thread = new Thread(processTask);
            thread.setDaemon(true);
            thread.start();
        });

        // 📄 List click → popup
        listView.setOnMouseClicked(event -> {
            String selectedWordRaw = listView.getSelectionModel().getSelectedItem();
            if (selectedWordRaw == null) return;

            String selectedWord = selectedWordRaw.split(" ")[0];
            if (!uniqueSets.containsKey(selectedWord)) return;

            List<FileFreq> fileFreqs = uniqueSets.get(selectedWord);
            ListView<String> popupList = new ListView<>();
            Map<String, String> pathMap = new LinkedHashMap<>();

            for (FileFreq f : fileFreqs) {
                String label = f.getName() + " (" + f.getFrequency() + ")";
                popupList.getItems().add(label);
                pathMap.put(label, f.getPath());
            }

            popupList.setPrefHeight(Math.min(300, fileFreqs.size() * 35 + 20));
            popupList.setOnMouseClicked(e -> {
                String selected = popupList.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    Launcher.hs.showDocument("file:///" + pathMap.get(selected));
                    ((Popup) popupList.getScene().getWindow()).hide();
                }
            });

            Popup popup = new Popup();
            popup.getContent().add(popupList);
            popup.show(Launcher.primaryStage);

// ESC key closes popup
            popupList.setOnKeyPressed(keyEvent -> {
                switch (keyEvent.getCode()) {
                    case ESCAPE -> popup.hide();
                }
            });
            popupList.requestFocus();
        });
    }

    @FXML
    private void handleStartIndexing() {
        if (inputListView.getItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "No PDF file found. Please drop at least one.");
            alert.show();
            return;
        }
    }
}